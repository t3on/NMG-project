The documentation is located at: https://pythonhosted.org/eelbrain/
