{{ fullname }}
{{ underline }}

.. automodule:: {{ fullname }}
