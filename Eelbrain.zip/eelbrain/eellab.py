from warnings import warn
warn("eelbrain.eellab imports are deprecated. Please import from eelbrain "
     "directly.", DeprecationWarning)

from eelbrain import *
