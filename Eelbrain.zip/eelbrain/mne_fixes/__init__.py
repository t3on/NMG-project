"""Some fixes relative to mne-python 0.8.1
"""

from _label import write_labels_to_annot
