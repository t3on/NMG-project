# Author: Christian Brodbeck <christianbrodbeck@nyu.edu>

from _eeg_systems import predefined_connectivity
